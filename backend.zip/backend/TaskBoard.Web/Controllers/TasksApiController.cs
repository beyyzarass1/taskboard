using Microsoft.AspNetCore.Mvc;
using TaskBoard.Web.Models;
using TaskBoard.Web.ViewModels;

namespace TaskBoard.Web.Controllers;

[ApiController]
[Route("api/tasks")]
public class TasksApiController : ControllerBase
{
    private static readonly List<TaskItem> Tasks = new();

    [HttpGet]
    public IActionResult GetAll()
    {
        return Ok(Tasks);
    }

    [HttpPost]
    public IActionResult Create(CreateTaskRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Title))
        {
            return BadRequest("Başlık zorunludur.");
        }

        var task = new TaskItem
        {
            Id = Tasks.Count + 1,
            Title = request.Title
        };

        Tasks.Add(task);

        return Created($"/api/tasks/{task.Id}", task);
    }

    [HttpPatch("{id}/status")]
    public IActionResult UpdateStatus(int id)
    {
        TaskItem? task = Tasks.FirstOrDefault(x => x.Id == id);

        if (task == null)
        {
            return NotFound();
        }

        task.IsCompleted = !task.IsCompleted;

        return Ok(task);
    }
}