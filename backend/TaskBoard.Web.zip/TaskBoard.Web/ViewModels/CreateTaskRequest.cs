using System.ComponentModel.DataAnnotations;

namespace TaskBoard.Web.ViewModels;

public class CreateTaskRequest
{
    [Required]
    [StringLength(80)]
    public string Title { get; set; } = "";
}